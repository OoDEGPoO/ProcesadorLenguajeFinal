// Generated from C:/Users/sergi/Desktop/EstrategiasCSV/src/gramaticas/GestrategiacsvParser.g4 by ANTLR 4.7

	package gramaticas;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class GestrategiacsvParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		JSON=1, SCHEMA=2, DOT=3, NEATO=4, SVG=5, DPTO=6, PTO=7, SLASH=8, SEPARADOR=9, 
		INTRO=10, TEXTO=11, CADENA=12;
	public static final int
		RULE_fichero = 0, RULE_cabecera = 1, RULE_linea = 2, RULE_columna = 3, 
		RULE_campo = 4, RULE_nombre = 5, RULE_rutafichero = 6, RULE_rutaficherosalida = 7, 
		RULE_rutaficherografico = 8, RULE_ruta = 9, RULE_cadena = 10, RULE_texto = 11, 
		RULE_dpto = 12, RULE_ext_json = 13, RULE_ext_schema = 14, RULE_ext_dot = 15, 
		RULE_ext_neato = 16, RULE_ext_svg = 17, RULE_intro = 18, RULE_separador = 19, 
		RULE_json = 20, RULE_schema = 21, RULE_dot = 22, RULE_neato = 23, RULE_svg = 24, 
		RULE_pto = 25, RULE_slash = 26;
	public static final String[] ruleNames = {
		"fichero", "cabecera", "linea", "columna", "campo", "nombre", "rutafichero", 
		"rutaficherosalida", "rutaficherografico", "ruta", "cadena", "texto", 
		"dpto", "ext_json", "ext_schema", "ext_dot", "ext_neato", "ext_svg", "intro", 
		"separador", "json", "schema", "dot", "neato", "svg", "pto", "slash"
	};

	private static final String[] _LITERAL_NAMES = {
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "JSON", "SCHEMA", "DOT", "NEATO", "SVG", "DPTO", "PTO", "SLASH", 
		"SEPARADOR", "INTRO", "TEXTO", "CADENA"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "GestrategiacsvParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public GestrategiacsvParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class FicheroContext extends ParserRuleContext {
		public CabeceraContext cabecera() {
			return getRuleContext(CabeceraContext.class,0);
		}
		public List<LineaContext> linea() {
			return getRuleContexts(LineaContext.class);
		}
		public LineaContext linea(int i) {
			return getRuleContext(LineaContext.class,i);
		}
		public FicheroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fichero; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterFichero(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitFichero(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitFichero(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FicheroContext fichero() throws RecognitionException {
		FicheroContext _localctx = new FicheroContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_fichero);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(54);
			cabecera();
			setState(56); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(55);
				linea();
				}
				}
				setState(58); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << PTO) | (1L << SLASH) | (1L << SEPARADOR) | (1L << INTRO) | (1L << TEXTO) | (1L << CADENA))) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CabeceraContext extends ParserRuleContext {
		public List<ColumnaContext> columna() {
			return getRuleContexts(ColumnaContext.class);
		}
		public ColumnaContext columna(int i) {
			return getRuleContext(ColumnaContext.class,i);
		}
		public TerminalNode INTRO() { return getToken(GestrategiacsvParser.INTRO, 0); }
		public List<TerminalNode> SEPARADOR() { return getTokens(GestrategiacsvParser.SEPARADOR); }
		public TerminalNode SEPARADOR(int i) {
			return getToken(GestrategiacsvParser.SEPARADOR, i);
		}
		public CabeceraContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cabecera; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterCabecera(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitCabecera(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitCabecera(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CabeceraContext cabecera() throws RecognitionException {
		CabeceraContext _localctx = new CabeceraContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_cabecera);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			columna();
			setState(65);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==SEPARADOR) {
				{
				{
				setState(61);
				match(SEPARADOR);
				setState(62);
				columna();
				}
				}
				setState(67);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(68);
			match(INTRO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LineaContext extends ParserRuleContext {
		public List<CampoContext> campo() {
			return getRuleContexts(CampoContext.class);
		}
		public CampoContext campo(int i) {
			return getRuleContext(CampoContext.class,i);
		}
		public TerminalNode INTRO() { return getToken(GestrategiacsvParser.INTRO, 0); }
		public List<TerminalNode> SEPARADOR() { return getTokens(GestrategiacsvParser.SEPARADOR); }
		public TerminalNode SEPARADOR(int i) {
			return getToken(GestrategiacsvParser.SEPARADOR, i);
		}
		public LineaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_linea; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterLinea(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitLinea(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitLinea(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LineaContext linea() throws RecognitionException {
		LineaContext _localctx = new LineaContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_linea);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(70);
			campo();
			setState(75);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==SEPARADOR) {
				{
				{
				setState(71);
				match(SEPARADOR);
				setState(72);
				campo();
				}
				}
				setState(77);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(78);
			match(INTRO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ColumnaContext extends ParserRuleContext {
		public ColumnaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_columna; }
	 
		public ColumnaContext() { }
		public void copyFrom(ColumnaContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ColumnaConComillasContext extends ColumnaContext {
		public CadenaContext cadena() {
			return getRuleContext(CadenaContext.class,0);
		}
		public ColumnaConComillasContext(ColumnaContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterColumnaConComillas(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitColumnaConComillas(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitColumnaConComillas(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ColumnaSinComillasContext extends ColumnaContext {
		public TextoContext texto() {
			return getRuleContext(TextoContext.class,0);
		}
		public ColumnaSinComillasContext(ColumnaContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterColumnaSinComillas(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitColumnaSinComillas(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitColumnaSinComillas(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ColumnaVacioContext extends ColumnaContext {
		public ColumnaVacioContext(ColumnaContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterColumnaVacio(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitColumnaVacio(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitColumnaVacio(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ColumnaContext columna() throws RecognitionException {
		ColumnaContext _localctx = new ColumnaContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_columna);
		try {
			setState(83);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TEXTO:
				_localctx = new ColumnaSinComillasContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(80);
				texto();
				}
				break;
			case CADENA:
				_localctx = new ColumnaConComillasContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(81);
				cadena();
				}
				break;
			case SEPARADOR:
			case INTRO:
				_localctx = new ColumnaVacioContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CampoContext extends ParserRuleContext {
		public CampoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_campo; }
	 
		public CampoContext() { }
		public void copyFrom(CampoContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class CampoVacioContext extends CampoContext {
		public CampoVacioContext(CampoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterCampoVacio(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitCampoVacio(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitCampoVacio(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RutaFicheroJsonContext extends CampoContext {
		public RutaficheroContext rutafichero() {
			return getRuleContext(RutaficheroContext.class,0);
		}
		public RutaFicheroJsonContext(CampoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRutaFicheroJson(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRutaFicheroJson(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRutaFicheroJson(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RutaFicheroSvgContext extends CampoContext {
		public RutaficherograficoContext rutaficherografico() {
			return getRuleContext(RutaficherograficoContext.class,0);
		}
		public RutaFicheroSvgContext(CampoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRutaFicheroSvg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRutaFicheroSvg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRutaFicheroSvg(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TextoNombreContext extends CampoContext {
		public NombreContext nombre() {
			return getRuleContext(NombreContext.class,0);
		}
		public TextoNombreContext(CampoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterTextoNombre(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitTextoNombre(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitTextoNombre(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RutaFicheroDotContext extends CampoContext {
		public RutaficherosalidaContext rutaficherosalida() {
			return getRuleContext(RutaficherosalidaContext.class,0);
		}
		public RutaFicheroDotContext(CampoContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRutaFicheroDot(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRutaFicheroDot(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRutaFicheroDot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CampoContext campo() throws RecognitionException {
		CampoContext _localctx = new CampoContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_campo);
		try {
			setState(90);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				_localctx = new RutaFicheroJsonContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(85);
				rutafichero();
				}
				break;
			case 2:
				_localctx = new RutaFicheroDotContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(86);
				rutaficherosalida();
				}
				break;
			case 3:
				_localctx = new RutaFicheroSvgContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(87);
				rutaficherografico();
				}
				break;
			case 4:
				_localctx = new TextoNombreContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(88);
				nombre();
				}
				break;
			case 5:
				_localctx = new CampoVacioContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NombreContext extends ParserRuleContext {
		public TextoContext texto() {
			return getRuleContext(TextoContext.class,0);
		}
		public CadenaContext cadena() {
			return getRuleContext(CadenaContext.class,0);
		}
		public NombreContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nombre; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterNombre(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitNombre(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitNombre(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NombreContext nombre() throws RecognitionException {
		NombreContext _localctx = new NombreContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_nombre);
		try {
			setState(94);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TEXTO:
				enterOuterAlt(_localctx, 1);
				{
				setState(92);
				texto();
				}
				break;
			case CADENA:
				enterOuterAlt(_localctx, 2);
				{
				setState(93);
				cadena();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RutaficheroContext extends ParserRuleContext {
		public RutaContext ruta() {
			return getRuleContext(RutaContext.class,0);
		}
		public Ext_jsonContext ext_json() {
			return getRuleContext(Ext_jsonContext.class,0);
		}
		public Ext_schemaContext ext_schema() {
			return getRuleContext(Ext_schemaContext.class,0);
		}
		public RutaficheroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rutafichero; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRutafichero(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRutafichero(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRutafichero(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RutaficheroContext rutafichero() throws RecognitionException {
		RutaficheroContext _localctx = new RutaficheroContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_rutafichero);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(96);
			ruta(0);
			setState(99);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				{
				setState(97);
				ext_json();
				}
				break;
			case 2:
				{
				setState(98);
				ext_schema();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RutaficherosalidaContext extends ParserRuleContext {
		public RutaContext ruta() {
			return getRuleContext(RutaContext.class,0);
		}
		public Ext_dotContext ext_dot() {
			return getRuleContext(Ext_dotContext.class,0);
		}
		public Ext_neatoContext ext_neato() {
			return getRuleContext(Ext_neatoContext.class,0);
		}
		public RutaficherosalidaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rutaficherosalida; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRutaficherosalida(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRutaficherosalida(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRutaficherosalida(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RutaficherosalidaContext rutaficherosalida() throws RecognitionException {
		RutaficherosalidaContext _localctx = new RutaficherosalidaContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_rutaficherosalida);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(101);
			ruta(0);
			setState(104);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				{
				setState(102);
				ext_dot();
				}
				break;
			case 2:
				{
				setState(103);
				ext_neato();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RutaficherograficoContext extends ParserRuleContext {
		public RutaContext ruta() {
			return getRuleContext(RutaContext.class,0);
		}
		public Ext_svgContext ext_svg() {
			return getRuleContext(Ext_svgContext.class,0);
		}
		public RutaficherograficoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rutaficherografico; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRutaficherografico(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRutaficherografico(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRutaficherografico(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RutaficherograficoContext rutaficherografico() throws RecognitionException {
		RutaficherograficoContext _localctx = new RutaficherograficoContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_rutaficherografico);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(106);
			ruta(0);
			setState(107);
			ext_svg();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RutaContext extends ParserRuleContext {
		public List<TerminalNode> PTO() { return getTokens(GestrategiacsvParser.PTO); }
		public TerminalNode PTO(int i) {
			return getToken(GestrategiacsvParser.PTO, i);
		}
		public SlashContext slash() {
			return getRuleContext(SlashContext.class,0);
		}
		public List<RutaContext> ruta() {
			return getRuleContexts(RutaContext.class);
		}
		public RutaContext ruta(int i) {
			return getRuleContext(RutaContext.class,i);
		}
		public TextoContext texto() {
			return getRuleContext(TextoContext.class,0);
		}
		public DptoContext dpto() {
			return getRuleContext(DptoContext.class,0);
		}
		public RutaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ruta; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterRuta(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitRuta(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitRuta(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RutaContext ruta() throws RecognitionException {
		return ruta(0);
	}

	private RutaContext ruta(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		RutaContext _localctx = new RutaContext(_ctx, _parentState);
		RutaContext _prevctx = _localctx;
		int _startState = 18;
		enterRecursionRule(_localctx, 18, RULE_ruta, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				{
				setState(110);
				match(PTO);
				setState(111);
				slash();
				setState(112);
				ruta(6);
				}
				break;
			case 2:
				{
				setState(114);
				match(PTO);
				setState(115);
				match(PTO);
				setState(116);
				slash();
				setState(117);
				ruta(5);
				}
				break;
			case 3:
				{
				setState(119);
				texto();
				setState(120);
				dpto();
				setState(121);
				slash();
				setState(122);
				ruta(4);
				}
				break;
			case 4:
				{
				setState(124);
				slash();
				setState(125);
				ruta(3);
				}
				break;
			case 5:
				{
				setState(127);
				texto();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(136);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new RutaContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_ruta);
					setState(130);
					if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
					setState(131);
					slash();
					setState(132);
					ruta(3);
					}
					} 
				}
				setState(138);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,9,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CadenaContext extends ParserRuleContext {
		public TerminalNode CADENA() { return getToken(GestrategiacsvParser.CADENA, 0); }
		public CadenaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cadena; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterCadena(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitCadena(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitCadena(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CadenaContext cadena() throws RecognitionException {
		CadenaContext _localctx = new CadenaContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_cadena);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(139);
			match(CADENA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TextoContext extends ParserRuleContext {
		public TerminalNode TEXTO() { return getToken(GestrategiacsvParser.TEXTO, 0); }
		public TextoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_texto; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterTexto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitTexto(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitTexto(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TextoContext texto() throws RecognitionException {
		TextoContext _localctx = new TextoContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_texto);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(141);
			match(TEXTO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DptoContext extends ParserRuleContext {
		public TerminalNode DPTO() { return getToken(GestrategiacsvParser.DPTO, 0); }
		public DptoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dpto; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterDpto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitDpto(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitDpto(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DptoContext dpto() throws RecognitionException {
		DptoContext _localctx = new DptoContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_dpto);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			match(DPTO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ext_jsonContext extends ParserRuleContext {
		public TerminalNode PTO() { return getToken(GestrategiacsvParser.PTO, 0); }
		public JsonContext json() {
			return getRuleContext(JsonContext.class,0);
		}
		public Ext_jsonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ext_json; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterExt_json(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitExt_json(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitExt_json(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ext_jsonContext ext_json() throws RecognitionException {
		Ext_jsonContext _localctx = new Ext_jsonContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_ext_json);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(145);
			match(PTO);
			setState(146);
			json();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ext_schemaContext extends ParserRuleContext {
		public PtoContext pto() {
			return getRuleContext(PtoContext.class,0);
		}
		public SchemaContext schema() {
			return getRuleContext(SchemaContext.class,0);
		}
		public Ext_schemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ext_schema; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterExt_schema(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitExt_schema(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitExt_schema(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ext_schemaContext ext_schema() throws RecognitionException {
		Ext_schemaContext _localctx = new Ext_schemaContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_ext_schema);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(148);
			pto();
			setState(149);
			schema();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ext_dotContext extends ParserRuleContext {
		public PtoContext pto() {
			return getRuleContext(PtoContext.class,0);
		}
		public DotContext dot() {
			return getRuleContext(DotContext.class,0);
		}
		public Ext_dotContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ext_dot; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterExt_dot(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitExt_dot(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitExt_dot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ext_dotContext ext_dot() throws RecognitionException {
		Ext_dotContext _localctx = new Ext_dotContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_ext_dot);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(151);
			pto();
			setState(152);
			dot();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ext_neatoContext extends ParserRuleContext {
		public PtoContext pto() {
			return getRuleContext(PtoContext.class,0);
		}
		public NeatoContext neato() {
			return getRuleContext(NeatoContext.class,0);
		}
		public Ext_neatoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ext_neato; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterExt_neato(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitExt_neato(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitExt_neato(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ext_neatoContext ext_neato() throws RecognitionException {
		Ext_neatoContext _localctx = new Ext_neatoContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_ext_neato);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(154);
			pto();
			setState(155);
			neato();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ext_svgContext extends ParserRuleContext {
		public PtoContext pto() {
			return getRuleContext(PtoContext.class,0);
		}
		public SvgContext svg() {
			return getRuleContext(SvgContext.class,0);
		}
		public Ext_svgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ext_svg; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterExt_svg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitExt_svg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitExt_svg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ext_svgContext ext_svg() throws RecognitionException {
		Ext_svgContext _localctx = new Ext_svgContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_ext_svg);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(157);
			pto();
			setState(158);
			svg();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntroContext extends ParserRuleContext {
		public TerminalNode INTRO() { return getToken(GestrategiacsvParser.INTRO, 0); }
		public IntroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_intro; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterIntro(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitIntro(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitIntro(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntroContext intro() throws RecognitionException {
		IntroContext _localctx = new IntroContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_intro);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(160);
			match(INTRO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SeparadorContext extends ParserRuleContext {
		public TerminalNode SEPARADOR() { return getToken(GestrategiacsvParser.SEPARADOR, 0); }
		public SeparadorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_separador; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterSeparador(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitSeparador(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitSeparador(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SeparadorContext separador() throws RecognitionException {
		SeparadorContext _localctx = new SeparadorContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_separador);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(162);
			match(SEPARADOR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class JsonContext extends ParserRuleContext {
		public TerminalNode JSON() { return getToken(GestrategiacsvParser.JSON, 0); }
		public JsonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_json; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterJson(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitJson(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitJson(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonContext json() throws RecognitionException {
		JsonContext _localctx = new JsonContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_json);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(164);
			match(JSON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SchemaContext extends ParserRuleContext {
		public TerminalNode SCHEMA() { return getToken(GestrategiacsvParser.SCHEMA, 0); }
		public SchemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_schema; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterSchema(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitSchema(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitSchema(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SchemaContext schema() throws RecognitionException {
		SchemaContext _localctx = new SchemaContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_schema);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(166);
			match(SCHEMA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DotContext extends ParserRuleContext {
		public TerminalNode DOT() { return getToken(GestrategiacsvParser.DOT, 0); }
		public DotContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dot; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterDot(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitDot(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitDot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DotContext dot() throws RecognitionException {
		DotContext _localctx = new DotContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_dot);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			match(DOT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NeatoContext extends ParserRuleContext {
		public TerminalNode NEATO() { return getToken(GestrategiacsvParser.NEATO, 0); }
		public NeatoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_neato; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterNeato(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitNeato(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitNeato(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NeatoContext neato() throws RecognitionException {
		NeatoContext _localctx = new NeatoContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_neato);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(170);
			match(NEATO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SvgContext extends ParserRuleContext {
		public TerminalNode SVG() { return getToken(GestrategiacsvParser.SVG, 0); }
		public SvgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_svg; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterSvg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitSvg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitSvg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SvgContext svg() throws RecognitionException {
		SvgContext _localctx = new SvgContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_svg);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(172);
			match(SVG);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PtoContext extends ParserRuleContext {
		public TerminalNode PTO() { return getToken(GestrategiacsvParser.PTO, 0); }
		public PtoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pto; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterPto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitPto(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitPto(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PtoContext pto() throws RecognitionException {
		PtoContext _localctx = new PtoContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_pto);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(174);
			match(PTO);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SlashContext extends ParserRuleContext {
		public TerminalNode SLASH() { return getToken(GestrategiacsvParser.SLASH, 0); }
		public SlashContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_slash; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).enterSlash(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GestrategiacsvParserListener ) ((GestrategiacsvParserListener)listener).exitSlash(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GestrategiacsvParserVisitor ) return ((GestrategiacsvParserVisitor<? extends T>)visitor).visitSlash(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SlashContext slash() throws RecognitionException {
		SlashContext _localctx = new SlashContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_slash);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(176);
			match(SLASH);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 9:
			return ruta_sempred((RutaContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean ruta_sempred(RutaContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\16\u00b5\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\3\2\3\2\6\2;\n\2\r\2\16\2<\3\3\3\3\3\3"+
		"\7\3B\n\3\f\3\16\3E\13\3\3\3\3\3\3\4\3\4\3\4\7\4L\n\4\f\4\16\4O\13\4\3"+
		"\4\3\4\3\5\3\5\3\5\5\5V\n\5\3\6\3\6\3\6\3\6\3\6\5\6]\n\6\3\7\3\7\5\7a"+
		"\n\7\3\b\3\b\3\b\5\bf\n\b\3\t\3\t\3\t\5\tk\n\t\3\n\3\n\3\n\3\13\3\13\3"+
		"\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3"+
		"\13\3\13\3\13\5\13\u0083\n\13\3\13\3\13\3\13\3\13\7\13\u0089\n\13\f\13"+
		"\16\13\u008c\13\13\3\f\3\f\3\r\3\r\3\16\3\16\3\17\3\17\3\17\3\20\3\20"+
		"\3\20\3\21\3\21\3\21\3\22\3\22\3\22\3\23\3\23\3\23\3\24\3\24\3\25\3\25"+
		"\3\26\3\26\3\27\3\27\3\30\3\30\3\31\3\31\3\32\3\32\3\33\3\33\3\34\3\34"+
		"\3\34\2\3\24\35\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62"+
		"\64\66\2\2\2\u00aa\28\3\2\2\2\4>\3\2\2\2\6H\3\2\2\2\bU\3\2\2\2\n\\\3\2"+
		"\2\2\f`\3\2\2\2\16b\3\2\2\2\20g\3\2\2\2\22l\3\2\2\2\24\u0082\3\2\2\2\26"+
		"\u008d\3\2\2\2\30\u008f\3\2\2\2\32\u0091\3\2\2\2\34\u0093\3\2\2\2\36\u0096"+
		"\3\2\2\2 \u0099\3\2\2\2\"\u009c\3\2\2\2$\u009f\3\2\2\2&\u00a2\3\2\2\2"+
		"(\u00a4\3\2\2\2*\u00a6\3\2\2\2,\u00a8\3\2\2\2.\u00aa\3\2\2\2\60\u00ac"+
		"\3\2\2\2\62\u00ae\3\2\2\2\64\u00b0\3\2\2\2\66\u00b2\3\2\2\28:\5\4\3\2"+
		"9;\5\6\4\2:9\3\2\2\2;<\3\2\2\2<:\3\2\2\2<=\3\2\2\2=\3\3\2\2\2>C\5\b\5"+
		"\2?@\7\13\2\2@B\5\b\5\2A?\3\2\2\2BE\3\2\2\2CA\3\2\2\2CD\3\2\2\2DF\3\2"+
		"\2\2EC\3\2\2\2FG\7\f\2\2G\5\3\2\2\2HM\5\n\6\2IJ\7\13\2\2JL\5\n\6\2KI\3"+
		"\2\2\2LO\3\2\2\2MK\3\2\2\2MN\3\2\2\2NP\3\2\2\2OM\3\2\2\2PQ\7\f\2\2Q\7"+
		"\3\2\2\2RV\5\30\r\2SV\5\26\f\2TV\3\2\2\2UR\3\2\2\2US\3\2\2\2UT\3\2\2\2"+
		"V\t\3\2\2\2W]\5\16\b\2X]\5\20\t\2Y]\5\22\n\2Z]\5\f\7\2[]\3\2\2\2\\W\3"+
		"\2\2\2\\X\3\2\2\2\\Y\3\2\2\2\\Z\3\2\2\2\\[\3\2\2\2]\13\3\2\2\2^a\5\30"+
		"\r\2_a\5\26\f\2`^\3\2\2\2`_\3\2\2\2a\r\3\2\2\2be\5\24\13\2cf\5\34\17\2"+
		"df\5\36\20\2ec\3\2\2\2ed\3\2\2\2f\17\3\2\2\2gj\5\24\13\2hk\5 \21\2ik\5"+
		"\"\22\2jh\3\2\2\2ji\3\2\2\2k\21\3\2\2\2lm\5\24\13\2mn\5$\23\2n\23\3\2"+
		"\2\2op\b\13\1\2pq\7\t\2\2qr\5\66\34\2rs\5\24\13\bs\u0083\3\2\2\2tu\7\t"+
		"\2\2uv\7\t\2\2vw\5\66\34\2wx\5\24\13\7x\u0083\3\2\2\2yz\5\30\r\2z{\5\32"+
		"\16\2{|\5\66\34\2|}\5\24\13\6}\u0083\3\2\2\2~\177\5\66\34\2\177\u0080"+
		"\5\24\13\5\u0080\u0083\3\2\2\2\u0081\u0083\5\30\r\2\u0082o\3\2\2\2\u0082"+
		"t\3\2\2\2\u0082y\3\2\2\2\u0082~\3\2\2\2\u0082\u0081\3\2\2\2\u0083\u008a"+
		"\3\2\2\2\u0084\u0085\f\4\2\2\u0085\u0086\5\66\34\2\u0086\u0087\5\24\13"+
		"\5\u0087\u0089\3\2\2\2\u0088\u0084\3\2\2\2\u0089\u008c\3\2\2\2\u008a\u0088"+
		"\3\2\2\2\u008a\u008b\3\2\2\2\u008b\25\3\2\2\2\u008c\u008a\3\2\2\2\u008d"+
		"\u008e\7\16\2\2\u008e\27\3\2\2\2\u008f\u0090\7\r\2\2\u0090\31\3\2\2\2"+
		"\u0091\u0092\7\b\2\2\u0092\33\3\2\2\2\u0093\u0094\7\t\2\2\u0094\u0095"+
		"\5*\26\2\u0095\35\3\2\2\2\u0096\u0097\5\64\33\2\u0097\u0098\5,\27\2\u0098"+
		"\37\3\2\2\2\u0099\u009a\5\64\33\2\u009a\u009b\5.\30\2\u009b!\3\2\2\2\u009c"+
		"\u009d\5\64\33\2\u009d\u009e\5\60\31\2\u009e#\3\2\2\2\u009f\u00a0\5\64"+
		"\33\2\u00a0\u00a1\5\62\32\2\u00a1%\3\2\2\2\u00a2\u00a3\7\f\2\2\u00a3\'"+
		"\3\2\2\2\u00a4\u00a5\7\13\2\2\u00a5)\3\2\2\2\u00a6\u00a7\7\3\2\2\u00a7"+
		"+\3\2\2\2\u00a8\u00a9\7\4\2\2\u00a9-\3\2\2\2\u00aa\u00ab\7\5\2\2\u00ab"+
		"/\3\2\2\2\u00ac\u00ad\7\6\2\2\u00ad\61\3\2\2\2\u00ae\u00af\7\7\2\2\u00af"+
		"\63\3\2\2\2\u00b0\u00b1\7\t\2\2\u00b1\65\3\2\2\2\u00b2\u00b3\7\n\2\2\u00b3"+
		"\67\3\2\2\2\f<CMU\\`ej\u0082\u008a";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}