// Generated from C:/Users/sergi/Desktop/EstrategiasCSV/src/gramaticas/GestrategiacsvParser.g4 by ANTLR 4.7

	package gramaticas;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link GestrategiacsvParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface GestrategiacsvParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#fichero}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFichero(GestrategiacsvParser.FicheroContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#cabecera}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCabecera(GestrategiacsvParser.CabeceraContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#linea}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLinea(GestrategiacsvParser.LineaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code columnaSinComillas}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumnaSinComillas(GestrategiacsvParser.ColumnaSinComillasContext ctx);
	/**
	 * Visit a parse tree produced by the {@code columnaConComillas}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumnaConComillas(GestrategiacsvParser.ColumnaConComillasContext ctx);
	/**
	 * Visit a parse tree produced by the {@code columnaVacio}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumnaVacio(GestrategiacsvParser.ColumnaVacioContext ctx);
	/**
	 * Visit a parse tree produced by the {@code rutaFicheroJson}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRutaFicheroJson(GestrategiacsvParser.RutaFicheroJsonContext ctx);
	/**
	 * Visit a parse tree produced by the {@code rutaFicheroDot}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRutaFicheroDot(GestrategiacsvParser.RutaFicheroDotContext ctx);
	/**
	 * Visit a parse tree produced by the {@code rutaFicheroSvg}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRutaFicheroSvg(GestrategiacsvParser.RutaFicheroSvgContext ctx);
	/**
	 * Visit a parse tree produced by the {@code textoNombre}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTextoNombre(GestrategiacsvParser.TextoNombreContext ctx);
	/**
	 * Visit a parse tree produced by the {@code campoVacio}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCampoVacio(GestrategiacsvParser.CampoVacioContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#nombre}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNombre(GestrategiacsvParser.NombreContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#rutafichero}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRutafichero(GestrategiacsvParser.RutaficheroContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#rutaficherosalida}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRutaficherosalida(GestrategiacsvParser.RutaficherosalidaContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#rutaficherografico}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRutaficherografico(GestrategiacsvParser.RutaficherograficoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#ruta}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRuta(GestrategiacsvParser.RutaContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#cadena}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCadena(GestrategiacsvParser.CadenaContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#texto}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTexto(GestrategiacsvParser.TextoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#dpto}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDpto(GestrategiacsvParser.DptoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#ext_json}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExt_json(GestrategiacsvParser.Ext_jsonContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#ext_schema}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExt_schema(GestrategiacsvParser.Ext_schemaContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#ext_dot}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExt_dot(GestrategiacsvParser.Ext_dotContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#ext_neato}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExt_neato(GestrategiacsvParser.Ext_neatoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#ext_svg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExt_svg(GestrategiacsvParser.Ext_svgContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#intro}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntro(GestrategiacsvParser.IntroContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#separador}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSeparador(GestrategiacsvParser.SeparadorContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#json}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJson(GestrategiacsvParser.JsonContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#schema}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSchema(GestrategiacsvParser.SchemaContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#dot}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDot(GestrategiacsvParser.DotContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#neato}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNeato(GestrategiacsvParser.NeatoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#svg}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSvg(GestrategiacsvParser.SvgContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#pto}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPto(GestrategiacsvParser.PtoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GestrategiacsvParser#slash}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSlash(GestrategiacsvParser.SlashContext ctx);
}