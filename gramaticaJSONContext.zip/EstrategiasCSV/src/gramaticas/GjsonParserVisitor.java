// Generated from C:/Users/sergi/Desktop/EstrategiasCSV/src/gramaticas/GjsonParser.g4 by ANTLR 4.7

	package gramaticas;


import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link GjsonParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface GjsonParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link GjsonParser#json}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJson(GjsonParser.JsonContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#context}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContext(GjsonParser.ContextContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#clase}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClase(GjsonParser.ClaseContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#clasescontext}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClasescontext(GjsonParser.ClasescontextContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#pcontext}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPcontext(GjsonParser.PcontextContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#atributos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtributos(GjsonParser.AtributosContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#propiedad}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPropiedad(GjsonParser.PropiedadContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#gprop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGprop(GjsonParser.GpropContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#pr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr(GjsonParser.PrContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#pr_cuerpo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPr_cuerpo(GjsonParser.Pr_cuerpoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#xsd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXsd(GjsonParser.XsdContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitId(GjsonParser.IdContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#tipo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo(GjsonParser.TipoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#mandatory}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMandatory(GjsonParser.MandatoryContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#container}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContainer(GjsonParser.ContainerContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue(GjsonParser.ValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link GjsonParser#contextpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContextpr(GjsonParser.ContextprContext ctx);
}