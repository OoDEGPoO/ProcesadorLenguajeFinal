// Generated from C:/Users/sergi/Desktop/EstrategiasCSV/src/gramaticas/GjsonParser.g4 by ANTLR 4.7

	package gramaticas;


import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class GjsonParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		SEPARADOR=1, ABRIRETIQUETA=2, CERRARETIQUETA=3, DP=4, ABRIRCORCHETE=5, 
		CERRARCORCHETE=6, ID=7, TYPE=8, MANDATORY=9, CONTAINER=10, VALUE=11, CONTEXT=12, 
		TRUE=13, FALSE=14, XSD=15, CADENA=16, INTRO=17, WS=18, TAB=19;
	public static final int
		RULE_json = 0, RULE_context = 1, RULE_clase = 2, RULE_clasescontext = 3, 
		RULE_pcontext = 4, RULE_atributos = 5, RULE_propiedad = 6, RULE_gprop = 7, 
		RULE_pr = 8, RULE_pr_cuerpo = 9, RULE_xsd = 10, RULE_id = 11, RULE_tipo = 12, 
		RULE_mandatory = 13, RULE_container = 14, RULE_value = 15, RULE_contextpr = 16;
	public static final String[] ruleNames = {
		"json", "context", "clase", "clasescontext", "pcontext", "atributos", 
		"propiedad", "gprop", "pr", "pr_cuerpo", "xsd", "id", "tipo", "mandatory", 
		"container", "value", "contextpr"
	};

	private static final String[] _LITERAL_NAMES = {
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "SEPARADOR", "ABRIRETIQUETA", "CERRARETIQUETA", "DP", "ABRIRCORCHETE", 
		"CERRARCORCHETE", "ID", "TYPE", "MANDATORY", "CONTAINER", "VALUE", "CONTEXT", 
		"TRUE", "FALSE", "XSD", "CADENA", "INTRO", "WS", "TAB"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "GjsonParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public GjsonParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class JsonContext extends ParserRuleContext {
		public TerminalNode ABRIRETIQUETA() { return getToken(GjsonParser.ABRIRETIQUETA, 0); }
		public ContextContext context() {
			return getRuleContext(ContextContext.class,0);
		}
		public TerminalNode CERRARETIQUETA() { return getToken(GjsonParser.CERRARETIQUETA, 0); }
		public JsonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_json; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterJson(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitJson(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitJson(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JsonContext json() throws RecognitionException {
		JsonContext _localctx = new JsonContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_json);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(34);
			match(ABRIRETIQUETA);
			setState(35);
			context();
			setState(36);
			match(CERRARETIQUETA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ContextContext extends ParserRuleContext {
		public ContextprContext contextpr() {
			return getRuleContext(ContextprContext.class,0);
		}
		public TerminalNode DP() { return getToken(GjsonParser.DP, 0); }
		public TerminalNode ABRIRETIQUETA() { return getToken(GjsonParser.ABRIRETIQUETA, 0); }
		public ClaseContext clase() {
			return getRuleContext(ClaseContext.class,0);
		}
		public TerminalNode CERRARETIQUETA() { return getToken(GjsonParser.CERRARETIQUETA, 0); }
		public ContextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_context; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterContext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitContext(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitContext(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContextContext context() throws RecognitionException {
		ContextContext _localctx = new ContextContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_context);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(38);
			contextpr();
			setState(39);
			match(DP);
			setState(40);
			match(ABRIRETIQUETA);
			setState(41);
			clase();
			setState(42);
			match(CERRARETIQUETA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClaseContext extends ParserRuleContext {
		public ClasescontextContext clasescontext() {
			return getRuleContext(ClasescontextContext.class,0);
		}
		public TerminalNode SEPARADOR() { return getToken(GjsonParser.SEPARADOR, 0); }
		public ClaseContext clase() {
			return getRuleContext(ClaseContext.class,0);
		}
		public ClaseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clase; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterClase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitClase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitClase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClaseContext clase() throws RecognitionException {
		ClaseContext _localctx = new ClaseContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_clase);
		try {
			setState(49);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(44);
				clasescontext();
				setState(45);
				match(SEPARADOR);
				setState(46);
				clase();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(48);
				clasescontext();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClasescontextContext extends ParserRuleContext {
		public XsdContext xsd() {
			return getRuleContext(XsdContext.class,0);
		}
		public PcontextContext pcontext() {
			return getRuleContext(PcontextContext.class,0);
		}
		public ClasescontextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clasescontext; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterClasescontext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitClasescontext(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitClasescontext(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClasescontextContext clasescontext() throws RecognitionException {
		ClasescontextContext _localctx = new ClasescontextContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_clasescontext);
		try {
			setState(53);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case XSD:
				enterOuterAlt(_localctx, 1);
				{
				setState(51);
				xsd();
				}
				break;
			case CADENA:
				enterOuterAlt(_localctx, 2);
				{
				setState(52);
				pcontext();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PcontextContext extends ParserRuleContext {
		public TerminalNode CADENA() { return getToken(GjsonParser.CADENA, 0); }
		public TerminalNode DP() { return getToken(GjsonParser.DP, 0); }
		public TerminalNode ABRIRETIQUETA() { return getToken(GjsonParser.ABRIRETIQUETA, 0); }
		public AtributosContext atributos() {
			return getRuleContext(AtributosContext.class,0);
		}
		public TerminalNode CERRARETIQUETA() { return getToken(GjsonParser.CERRARETIQUETA, 0); }
		public PcontextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pcontext; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterPcontext(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitPcontext(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitPcontext(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PcontextContext pcontext() throws RecognitionException {
		PcontextContext _localctx = new PcontextContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_pcontext);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			match(CADENA);
			setState(56);
			match(DP);
			setState(57);
			match(ABRIRETIQUETA);
			setState(58);
			atributos();
			setState(59);
			match(CERRARETIQUETA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtributosContext extends ParserRuleContext {
		public PropiedadContext propiedad() {
			return getRuleContext(PropiedadContext.class,0);
		}
		public TerminalNode SEPARADOR() { return getToken(GjsonParser.SEPARADOR, 0); }
		public AtributosContext atributos() {
			return getRuleContext(AtributosContext.class,0);
		}
		public AtributosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atributos; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterAtributos(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitAtributos(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitAtributos(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtributosContext atributos() throws RecognitionException {
		AtributosContext _localctx = new AtributosContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_atributos);
		try {
			setState(66);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(61);
				propiedad();
				setState(62);
				match(SEPARADOR);
				setState(63);
				atributos();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(65);
				propiedad();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PropiedadContext extends ParserRuleContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode DP() { return getToken(GjsonParser.DP, 0); }
		public TerminalNode CADENA() { return getToken(GjsonParser.CADENA, 0); }
		public GpropContext gprop() {
			return getRuleContext(GpropContext.class,0);
		}
		public PropiedadContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_propiedad; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterPropiedad(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitPropiedad(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitPropiedad(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PropiedadContext propiedad() throws RecognitionException {
		PropiedadContext _localctx = new PropiedadContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_propiedad);
		try {
			setState(73);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(68);
				id();
				setState(69);
				match(DP);
				setState(70);
				match(CADENA);
				}
				break;
			case CADENA:
				enterOuterAlt(_localctx, 2);
				{
				setState(72);
				gprop();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GpropContext extends ParserRuleContext {
		public TerminalNode CADENA() { return getToken(GjsonParser.CADENA, 0); }
		public TerminalNode DP() { return getToken(GjsonParser.DP, 0); }
		public TerminalNode ABRIRETIQUETA() { return getToken(GjsonParser.ABRIRETIQUETA, 0); }
		public PrContext pr() {
			return getRuleContext(PrContext.class,0);
		}
		public TerminalNode CERRARETIQUETA() { return getToken(GjsonParser.CERRARETIQUETA, 0); }
		public GpropContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_gprop; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterGprop(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitGprop(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitGprop(this);
			else return visitor.visitChildren(this);
		}
	}

	public final GpropContext gprop() throws RecognitionException {
		GpropContext _localctx = new GpropContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_gprop);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(75);
			match(CADENA);
			setState(76);
			match(DP);
			setState(77);
			match(ABRIRETIQUETA);
			setState(78);
			pr();
			setState(79);
			match(CERRARETIQUETA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrContext extends ParserRuleContext {
		public Pr_cuerpoContext pr_cuerpo() {
			return getRuleContext(Pr_cuerpoContext.class,0);
		}
		public TerminalNode SEPARADOR() { return getToken(GjsonParser.SEPARADOR, 0); }
		public PrContext pr() {
			return getRuleContext(PrContext.class,0);
		}
		public PrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterPr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitPr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitPr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrContext pr() throws RecognitionException {
		PrContext _localctx = new PrContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_pr);
		try {
			setState(86);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(81);
				pr_cuerpo();
				setState(82);
				match(SEPARADOR);
				setState(83);
				pr();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(85);
				pr_cuerpo();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Pr_cuerpoContext extends ParserRuleContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode DP() { return getToken(GjsonParser.DP, 0); }
		public TerminalNode CADENA() { return getToken(GjsonParser.CADENA, 0); }
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public MandatoryContext mandatory() {
			return getRuleContext(MandatoryContext.class,0);
		}
		public TerminalNode TRUE() { return getToken(GjsonParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(GjsonParser.FALSE, 0); }
		public ContainerContext container() {
			return getRuleContext(ContainerContext.class,0);
		}
		public ValueContext value() {
			return getRuleContext(ValueContext.class,0);
		}
		public Pr_cuerpoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pr_cuerpo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterPr_cuerpo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitPr_cuerpo(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitPr_cuerpo(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Pr_cuerpoContext pr_cuerpo() throws RecognitionException {
		Pr_cuerpoContext _localctx = new Pr_cuerpoContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_pr_cuerpo);
		int _la;
		try {
			setState(108);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(88);
				id();
				setState(89);
				match(DP);
				setState(90);
				match(CADENA);
				}
				break;
			case TYPE:
				enterOuterAlt(_localctx, 2);
				{
				setState(92);
				tipo();
				setState(93);
				match(DP);
				setState(94);
				match(CADENA);
				}
				break;
			case MANDATORY:
				enterOuterAlt(_localctx, 3);
				{
				setState(96);
				mandatory();
				setState(97);
				match(DP);
				setState(98);
				_la = _input.LA(1);
				if ( !(_la==TRUE || _la==FALSE) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CONTAINER:
				enterOuterAlt(_localctx, 4);
				{
				setState(100);
				container();
				setState(101);
				match(DP);
				setState(102);
				match(CADENA);
				}
				break;
			case VALUE:
				enterOuterAlt(_localctx, 5);
				{
				setState(104);
				value();
				setState(105);
				match(DP);
				setState(106);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TRUE) | (1L << FALSE) | (1L << CADENA))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class XsdContext extends ParserRuleContext {
		public TerminalNode XSD() { return getToken(GjsonParser.XSD, 0); }
		public TerminalNode DP() { return getToken(GjsonParser.DP, 0); }
		public TerminalNode CADENA() { return getToken(GjsonParser.CADENA, 0); }
		public XsdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_xsd; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterXsd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitXsd(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitXsd(this);
			else return visitor.visitChildren(this);
		}
	}

	public final XsdContext xsd() throws RecognitionException {
		XsdContext _localctx = new XsdContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_xsd);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(110);
			match(XSD);
			setState(111);
			match(DP);
			setState(112);
			match(CADENA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(GjsonParser.ID, 0); }
		public IdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_id; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitId(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdContext id() throws RecognitionException {
		IdContext _localctx = new IdContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_id);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(114);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TipoContext extends ParserRuleContext {
		public TerminalNode TYPE() { return getToken(GjsonParser.TYPE, 0); }
		public TipoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterTipo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitTipo(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitTipo(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TipoContext tipo() throws RecognitionException {
		TipoContext _localctx = new TipoContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_tipo);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(116);
			match(TYPE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MandatoryContext extends ParserRuleContext {
		public TerminalNode MANDATORY() { return getToken(GjsonParser.MANDATORY, 0); }
		public MandatoryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mandatory; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterMandatory(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitMandatory(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitMandatory(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MandatoryContext mandatory() throws RecognitionException {
		MandatoryContext _localctx = new MandatoryContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_mandatory);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(118);
			match(MANDATORY);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ContainerContext extends ParserRuleContext {
		public TerminalNode CONTAINER() { return getToken(GjsonParser.CONTAINER, 0); }
		public ContainerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_container; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterContainer(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitContainer(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitContainer(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContainerContext container() throws RecognitionException {
		ContainerContext _localctx = new ContainerContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_container);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(120);
			match(CONTAINER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ValueContext extends ParserRuleContext {
		public TerminalNode VALUE() { return getToken(GjsonParser.VALUE, 0); }
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_value);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(122);
			match(VALUE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ContextprContext extends ParserRuleContext {
		public TerminalNode CONTEXT() { return getToken(GjsonParser.CONTEXT, 0); }
		public ContextprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_contextpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).enterContextpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof GjsonParserListener ) ((GjsonParserListener)listener).exitContextpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof GjsonParserVisitor ) return ((GjsonParserVisitor<? extends T>)visitor).visitContextpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContextprContext contextpr() throws RecognitionException {
		ContextprContext _localctx = new ContextprContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_contextpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(124);
			match(CONTEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\25\u0081\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\3\2\3\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\3\4\3\4\3\4\3\4\3\4\5\4\64\n"+
		"\4\3\5\3\5\5\58\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\5\7E\n"+
		"\7\3\b\3\b\3\b\3\b\3\b\5\bL\n\b\3\t\3\t\3\t\3\t\3\t\3\t\3\n\3\n\3\n\3"+
		"\n\3\n\5\nY\n\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13"+
		"\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\5\13o\n\13\3\f\3\f\3\f\3"+
		"\f\3\r\3\r\3\16\3\16\3\17\3\17\3\20\3\20\3\21\3\21\3\22\3\22\3\22\2\2"+
		"\23\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"\2\4\3\2\17\20\4\2\17\20"+
		"\22\22\2x\2$\3\2\2\2\4(\3\2\2\2\6\63\3\2\2\2\b\67\3\2\2\2\n9\3\2\2\2\f"+
		"D\3\2\2\2\16K\3\2\2\2\20M\3\2\2\2\22X\3\2\2\2\24n\3\2\2\2\26p\3\2\2\2"+
		"\30t\3\2\2\2\32v\3\2\2\2\34x\3\2\2\2\36z\3\2\2\2 |\3\2\2\2\"~\3\2\2\2"+
		"$%\7\4\2\2%&\5\4\3\2&\'\7\5\2\2\'\3\3\2\2\2()\5\"\22\2)*\7\6\2\2*+\7\4"+
		"\2\2+,\5\6\4\2,-\7\5\2\2-\5\3\2\2\2./\5\b\5\2/\60\7\3\2\2\60\61\5\6\4"+
		"\2\61\64\3\2\2\2\62\64\5\b\5\2\63.\3\2\2\2\63\62\3\2\2\2\64\7\3\2\2\2"+
		"\658\5\26\f\2\668\5\n\6\2\67\65\3\2\2\2\67\66\3\2\2\28\t\3\2\2\29:\7\22"+
		"\2\2:;\7\6\2\2;<\7\4\2\2<=\5\f\7\2=>\7\5\2\2>\13\3\2\2\2?@\5\16\b\2@A"+
		"\7\3\2\2AB\5\f\7\2BE\3\2\2\2CE\5\16\b\2D?\3\2\2\2DC\3\2\2\2E\r\3\2\2\2"+
		"FG\5\30\r\2GH\7\6\2\2HI\7\22\2\2IL\3\2\2\2JL\5\20\t\2KF\3\2\2\2KJ\3\2"+
		"\2\2L\17\3\2\2\2MN\7\22\2\2NO\7\6\2\2OP\7\4\2\2PQ\5\22\n\2QR\7\5\2\2R"+
		"\21\3\2\2\2ST\5\24\13\2TU\7\3\2\2UV\5\22\n\2VY\3\2\2\2WY\5\24\13\2XS\3"+
		"\2\2\2XW\3\2\2\2Y\23\3\2\2\2Z[\5\30\r\2[\\\7\6\2\2\\]\7\22\2\2]o\3\2\2"+
		"\2^_\5\32\16\2_`\7\6\2\2`a\7\22\2\2ao\3\2\2\2bc\5\34\17\2cd\7\6\2\2de"+
		"\t\2\2\2eo\3\2\2\2fg\5\36\20\2gh\7\6\2\2hi\7\22\2\2io\3\2\2\2jk\5 \21"+
		"\2kl\7\6\2\2lm\t\3\2\2mo\3\2\2\2nZ\3\2\2\2n^\3\2\2\2nb\3\2\2\2nf\3\2\2"+
		"\2nj\3\2\2\2o\25\3\2\2\2pq\7\21\2\2qr\7\6\2\2rs\7\22\2\2s\27\3\2\2\2t"+
		"u\7\t\2\2u\31\3\2\2\2vw\7\n\2\2w\33\3\2\2\2xy\7\13\2\2y\35\3\2\2\2z{\7"+
		"\f\2\2{\37\3\2\2\2|}\7\r\2\2}!\3\2\2\2~\177\7\16\2\2\177#\3\2\2\2\b\63"+
		"\67DKXn";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}