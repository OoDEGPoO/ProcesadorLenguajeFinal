// Generated from C:/Users/sergi/Desktop/EstrategiasCSV/src/gramaticas/GestrategiacsvParser.g4 by ANTLR 4.7

	package gramaticas;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link GestrategiacsvParser}.
 */
public interface GestrategiacsvParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#fichero}.
	 * @param ctx the parse tree
	 */
	void enterFichero(GestrategiacsvParser.FicheroContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#fichero}.
	 * @param ctx the parse tree
	 */
	void exitFichero(GestrategiacsvParser.FicheroContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#cabecera}.
	 * @param ctx the parse tree
	 */
	void enterCabecera(GestrategiacsvParser.CabeceraContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#cabecera}.
	 * @param ctx the parse tree
	 */
	void exitCabecera(GestrategiacsvParser.CabeceraContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#linea}.
	 * @param ctx the parse tree
	 */
	void enterLinea(GestrategiacsvParser.LineaContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#linea}.
	 * @param ctx the parse tree
	 */
	void exitLinea(GestrategiacsvParser.LineaContext ctx);
	/**
	 * Enter a parse tree produced by the {@code columnaSinComillas}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 */
	void enterColumnaSinComillas(GestrategiacsvParser.ColumnaSinComillasContext ctx);
	/**
	 * Exit a parse tree produced by the {@code columnaSinComillas}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 */
	void exitColumnaSinComillas(GestrategiacsvParser.ColumnaSinComillasContext ctx);
	/**
	 * Enter a parse tree produced by the {@code columnaConComillas}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 */
	void enterColumnaConComillas(GestrategiacsvParser.ColumnaConComillasContext ctx);
	/**
	 * Exit a parse tree produced by the {@code columnaConComillas}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 */
	void exitColumnaConComillas(GestrategiacsvParser.ColumnaConComillasContext ctx);
	/**
	 * Enter a parse tree produced by the {@code columnaVacio}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 */
	void enterColumnaVacio(GestrategiacsvParser.ColumnaVacioContext ctx);
	/**
	 * Exit a parse tree produced by the {@code columnaVacio}
	 * labeled alternative in {@link GestrategiacsvParser#columna}.
	 * @param ctx the parse tree
	 */
	void exitColumnaVacio(GestrategiacsvParser.ColumnaVacioContext ctx);
	/**
	 * Enter a parse tree produced by the {@code rutaFicheroJson}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void enterRutaFicheroJson(GestrategiacsvParser.RutaFicheroJsonContext ctx);
	/**
	 * Exit a parse tree produced by the {@code rutaFicheroJson}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void exitRutaFicheroJson(GestrategiacsvParser.RutaFicheroJsonContext ctx);
	/**
	 * Enter a parse tree produced by the {@code rutaFicheroDot}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void enterRutaFicheroDot(GestrategiacsvParser.RutaFicheroDotContext ctx);
	/**
	 * Exit a parse tree produced by the {@code rutaFicheroDot}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void exitRutaFicheroDot(GestrategiacsvParser.RutaFicheroDotContext ctx);
	/**
	 * Enter a parse tree produced by the {@code rutaFicheroSvg}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void enterRutaFicheroSvg(GestrategiacsvParser.RutaFicheroSvgContext ctx);
	/**
	 * Exit a parse tree produced by the {@code rutaFicheroSvg}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void exitRutaFicheroSvg(GestrategiacsvParser.RutaFicheroSvgContext ctx);
	/**
	 * Enter a parse tree produced by the {@code textoNombre}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void enterTextoNombre(GestrategiacsvParser.TextoNombreContext ctx);
	/**
	 * Exit a parse tree produced by the {@code textoNombre}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void exitTextoNombre(GestrategiacsvParser.TextoNombreContext ctx);
	/**
	 * Enter a parse tree produced by the {@code campoVacio}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void enterCampoVacio(GestrategiacsvParser.CampoVacioContext ctx);
	/**
	 * Exit a parse tree produced by the {@code campoVacio}
	 * labeled alternative in {@link GestrategiacsvParser#campo}.
	 * @param ctx the parse tree
	 */
	void exitCampoVacio(GestrategiacsvParser.CampoVacioContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#nombre}.
	 * @param ctx the parse tree
	 */
	void enterNombre(GestrategiacsvParser.NombreContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#nombre}.
	 * @param ctx the parse tree
	 */
	void exitNombre(GestrategiacsvParser.NombreContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#rutafichero}.
	 * @param ctx the parse tree
	 */
	void enterRutafichero(GestrategiacsvParser.RutaficheroContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#rutafichero}.
	 * @param ctx the parse tree
	 */
	void exitRutafichero(GestrategiacsvParser.RutaficheroContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#rutaficherosalida}.
	 * @param ctx the parse tree
	 */
	void enterRutaficherosalida(GestrategiacsvParser.RutaficherosalidaContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#rutaficherosalida}.
	 * @param ctx the parse tree
	 */
	void exitRutaficherosalida(GestrategiacsvParser.RutaficherosalidaContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#rutaficherografico}.
	 * @param ctx the parse tree
	 */
	void enterRutaficherografico(GestrategiacsvParser.RutaficherograficoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#rutaficherografico}.
	 * @param ctx the parse tree
	 */
	void exitRutaficherografico(GestrategiacsvParser.RutaficherograficoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#ruta}.
	 * @param ctx the parse tree
	 */
	void enterRuta(GestrategiacsvParser.RutaContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#ruta}.
	 * @param ctx the parse tree
	 */
	void exitRuta(GestrategiacsvParser.RutaContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#cadena}.
	 * @param ctx the parse tree
	 */
	void enterCadena(GestrategiacsvParser.CadenaContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#cadena}.
	 * @param ctx the parse tree
	 */
	void exitCadena(GestrategiacsvParser.CadenaContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#texto}.
	 * @param ctx the parse tree
	 */
	void enterTexto(GestrategiacsvParser.TextoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#texto}.
	 * @param ctx the parse tree
	 */
	void exitTexto(GestrategiacsvParser.TextoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#dpto}.
	 * @param ctx the parse tree
	 */
	void enterDpto(GestrategiacsvParser.DptoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#dpto}.
	 * @param ctx the parse tree
	 */
	void exitDpto(GestrategiacsvParser.DptoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#ext_json}.
	 * @param ctx the parse tree
	 */
	void enterExt_json(GestrategiacsvParser.Ext_jsonContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#ext_json}.
	 * @param ctx the parse tree
	 */
	void exitExt_json(GestrategiacsvParser.Ext_jsonContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#ext_schema}.
	 * @param ctx the parse tree
	 */
	void enterExt_schema(GestrategiacsvParser.Ext_schemaContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#ext_schema}.
	 * @param ctx the parse tree
	 */
	void exitExt_schema(GestrategiacsvParser.Ext_schemaContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#ext_dot}.
	 * @param ctx the parse tree
	 */
	void enterExt_dot(GestrategiacsvParser.Ext_dotContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#ext_dot}.
	 * @param ctx the parse tree
	 */
	void exitExt_dot(GestrategiacsvParser.Ext_dotContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#ext_neato}.
	 * @param ctx the parse tree
	 */
	void enterExt_neato(GestrategiacsvParser.Ext_neatoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#ext_neato}.
	 * @param ctx the parse tree
	 */
	void exitExt_neato(GestrategiacsvParser.Ext_neatoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#ext_svg}.
	 * @param ctx the parse tree
	 */
	void enterExt_svg(GestrategiacsvParser.Ext_svgContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#ext_svg}.
	 * @param ctx the parse tree
	 */
	void exitExt_svg(GestrategiacsvParser.Ext_svgContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#intro}.
	 * @param ctx the parse tree
	 */
	void enterIntro(GestrategiacsvParser.IntroContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#intro}.
	 * @param ctx the parse tree
	 */
	void exitIntro(GestrategiacsvParser.IntroContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#separador}.
	 * @param ctx the parse tree
	 */
	void enterSeparador(GestrategiacsvParser.SeparadorContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#separador}.
	 * @param ctx the parse tree
	 */
	void exitSeparador(GestrategiacsvParser.SeparadorContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#json}.
	 * @param ctx the parse tree
	 */
	void enterJson(GestrategiacsvParser.JsonContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#json}.
	 * @param ctx the parse tree
	 */
	void exitJson(GestrategiacsvParser.JsonContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#schema}.
	 * @param ctx the parse tree
	 */
	void enterSchema(GestrategiacsvParser.SchemaContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#schema}.
	 * @param ctx the parse tree
	 */
	void exitSchema(GestrategiacsvParser.SchemaContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#dot}.
	 * @param ctx the parse tree
	 */
	void enterDot(GestrategiacsvParser.DotContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#dot}.
	 * @param ctx the parse tree
	 */
	void exitDot(GestrategiacsvParser.DotContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#neato}.
	 * @param ctx the parse tree
	 */
	void enterNeato(GestrategiacsvParser.NeatoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#neato}.
	 * @param ctx the parse tree
	 */
	void exitNeato(GestrategiacsvParser.NeatoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#svg}.
	 * @param ctx the parse tree
	 */
	void enterSvg(GestrategiacsvParser.SvgContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#svg}.
	 * @param ctx the parse tree
	 */
	void exitSvg(GestrategiacsvParser.SvgContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#pto}.
	 * @param ctx the parse tree
	 */
	void enterPto(GestrategiacsvParser.PtoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#pto}.
	 * @param ctx the parse tree
	 */
	void exitPto(GestrategiacsvParser.PtoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GestrategiacsvParser#slash}.
	 * @param ctx the parse tree
	 */
	void enterSlash(GestrategiacsvParser.SlashContext ctx);
	/**
	 * Exit a parse tree produced by {@link GestrategiacsvParser#slash}.
	 * @param ctx the parse tree
	 */
	void exitSlash(GestrategiacsvParser.SlashContext ctx);
}