package gramaticas;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.*;
import java.util.*;

public class Ejecucion {

	public static void main(String[] args) throws Exception {
		String inputFile = null;
		if (args.length > 0)
			inputFile = args[0];

		// Fuerzo la carga del fichero de pruebas
		inputFile = "C:\\Users\\sergi\\Desktop\\EstrategiasCSV\\Datos\\ficheros_a_procesar.csv";

		InputStream is = System.in;
		if (inputFile != null) {
			is = new FileInputStream(inputFile);
		}

		CharStream input = CharStreams.fromStream(is);

		GestrategiacsvLexer lexer = new GestrategiacsvLexer(input);

		CommonTokenStream tokens = new CommonTokenStream(lexer);

		GestrategiacsvParser parser = new GestrategiacsvParser(tokens);

		parser.setBuildParseTree(true);

		ParseTree tree = parser.fichero();

		// Creamos una tabla de simbolos de CSV
		TSimb_CSV_Avanzado miTablaDeSimbolos = new TSimb_CSV_Avanzado();

		// Configuramos el listener
		CSVListener_TipoAvanzadoTS TB = new CSVListener_TipoAvanzadoTS(miTablaDeSimbolos);

		ParseTreeWalker walker = new ParseTreeWalker();

		// Recorremos el arbol:

		walker.walk(TB, tree);

		
		
		//Que coja los par�metros que tengan como columna nombre, rutafichero,rutaficherosalida, rutaficherosvg
		System.out.println(miTablaDeSimbolos.toString());
		for (int i = 0; i < miTablaDeSimbolos.getFilas().size(); i++) {
			HashMap<String, String> aux = miTablaDeSimbolos.getFilas().get(i);
			ArrayList<String> aux2 = miTablaDeSimbolos.getColumnas();
			ArrayList<String> parametrosJson = new ArrayList<String>();
			for (int j = 0; j < aux2.size(); j++) {
				String aux3 = aux.get(aux2.get(j));
				parametrosJson.add(aux3);
			}
			System.out.println(parametrosJson.toString());

		}

	}

	//

	// Utilizariamos los datos normalmente

	// Usamos la tabla de simbolos

}
