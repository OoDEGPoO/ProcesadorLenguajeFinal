// Generated from C:/Users/sergi/Desktop/EstrategiasCSV/src/gramaticas/GjsonParser.g4 by ANTLR 4.7

	package gramaticas;


import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link GjsonParser}.
 */
public interface GjsonParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link GjsonParser#json}.
	 * @param ctx the parse tree
	 */
	void enterJson(GjsonParser.JsonContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#json}.
	 * @param ctx the parse tree
	 */
	void exitJson(GjsonParser.JsonContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#context}.
	 * @param ctx the parse tree
	 */
	void enterContext(GjsonParser.ContextContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#context}.
	 * @param ctx the parse tree
	 */
	void exitContext(GjsonParser.ContextContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#clase}.
	 * @param ctx the parse tree
	 */
	void enterClase(GjsonParser.ClaseContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#clase}.
	 * @param ctx the parse tree
	 */
	void exitClase(GjsonParser.ClaseContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#clasescontext}.
	 * @param ctx the parse tree
	 */
	void enterClasescontext(GjsonParser.ClasescontextContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#clasescontext}.
	 * @param ctx the parse tree
	 */
	void exitClasescontext(GjsonParser.ClasescontextContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#pcontext}.
	 * @param ctx the parse tree
	 */
	void enterPcontext(GjsonParser.PcontextContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#pcontext}.
	 * @param ctx the parse tree
	 */
	void exitPcontext(GjsonParser.PcontextContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#atributos}.
	 * @param ctx the parse tree
	 */
	void enterAtributos(GjsonParser.AtributosContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#atributos}.
	 * @param ctx the parse tree
	 */
	void exitAtributos(GjsonParser.AtributosContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#propiedad}.
	 * @param ctx the parse tree
	 */
	void enterPropiedad(GjsonParser.PropiedadContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#propiedad}.
	 * @param ctx the parse tree
	 */
	void exitPropiedad(GjsonParser.PropiedadContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#gprop}.
	 * @param ctx the parse tree
	 */
	void enterGprop(GjsonParser.GpropContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#gprop}.
	 * @param ctx the parse tree
	 */
	void exitGprop(GjsonParser.GpropContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#pr}.
	 * @param ctx the parse tree
	 */
	void enterPr(GjsonParser.PrContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#pr}.
	 * @param ctx the parse tree
	 */
	void exitPr(GjsonParser.PrContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#pr_cuerpo}.
	 * @param ctx the parse tree
	 */
	void enterPr_cuerpo(GjsonParser.Pr_cuerpoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#pr_cuerpo}.
	 * @param ctx the parse tree
	 */
	void exitPr_cuerpo(GjsonParser.Pr_cuerpoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#xsd}.
	 * @param ctx the parse tree
	 */
	void enterXsd(GjsonParser.XsdContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#xsd}.
	 * @param ctx the parse tree
	 */
	void exitXsd(GjsonParser.XsdContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#id}.
	 * @param ctx the parse tree
	 */
	void enterId(GjsonParser.IdContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#id}.
	 * @param ctx the parse tree
	 */
	void exitId(GjsonParser.IdContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#tipo}.
	 * @param ctx the parse tree
	 */
	void enterTipo(GjsonParser.TipoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#tipo}.
	 * @param ctx the parse tree
	 */
	void exitTipo(GjsonParser.TipoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#mandatory}.
	 * @param ctx the parse tree
	 */
	void enterMandatory(GjsonParser.MandatoryContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#mandatory}.
	 * @param ctx the parse tree
	 */
	void exitMandatory(GjsonParser.MandatoryContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#container}.
	 * @param ctx the parse tree
	 */
	void enterContainer(GjsonParser.ContainerContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#container}.
	 * @param ctx the parse tree
	 */
	void exitContainer(GjsonParser.ContainerContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(GjsonParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(GjsonParser.ValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link GjsonParser#contextpr}.
	 * @param ctx the parse tree
	 */
	void enterContextpr(GjsonParser.ContextprContext ctx);
	/**
	 * Exit a parse tree produced by {@link GjsonParser#contextpr}.
	 * @param ctx the parse tree
	 */
	void exitContextpr(GjsonParser.ContextprContext ctx);
}