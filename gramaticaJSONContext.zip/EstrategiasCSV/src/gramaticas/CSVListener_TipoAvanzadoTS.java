package gramaticas;

import gramaticas.GestrategiacsvParser.CabeceraContext;
import gramaticas.GestrategiacsvParser.CampoVacioContext;
import gramaticas.GestrategiacsvParser.ColumnaConComillasContext;
import gramaticas.GestrategiacsvParser.ColumnaSinComillasContext;
import gramaticas.GestrategiacsvParser.ColumnaVacioContext;
import gramaticas.GestrategiacsvParser.LineaContext;
import gramaticas.GestrategiacsvParser.RutaFicheroDotContext;
import gramaticas.GestrategiacsvParser.RutaFicheroJsonContext;
import gramaticas.GestrategiacsvParser.RutaFicheroSvgContext;
import gramaticas.GestrategiacsvParser.RutaficherosalidaContext;
import gramaticas.GestrategiacsvParser.TextoNombreContext;

import java.util.*;

public class CSVListener_TipoAvanzadoTS extends GestrategiacsvParserBaseListener {
	
	
	public static final String CAMPO_VACIO="";
	
	private TSimb_CSV_Avanzado _tablasimbolos;
	
	private boolean error = false;
	
	private CSVListener_TipoAvanzadoTS() {
		super();
	}
	
	public CSVListener_TipoAvanzadoTS(TSimb_CSV_Avanzado p_ts) {
		super();
		_tablasimbolos = p_ts;
	}
	
	public boolean hayError() {
		return error;
	}
	
	@Override
	public void exitColumnaConComillas(ColumnaConComillasContext ctx) {
		//_tablasimbolos.addColumn(ctx.CADENA().getText());
		_tablasimbolos.addColumn(ctx.cadena().getText());
	}
	
	@Override
	public void exitColumnaSinComillas(ColumnaSinComillasContext ctx) {
		_tablasimbolos.addColumn(ctx.texto().getText());
	}
	
	@Override
	public void exitColumnaVacio(ColumnaVacioContext ctx) {
		_tablasimbolos.addColumn(CSVListener_TipoAvanzadoTS.CAMPO_VACIO);
	}
	
	@Override
	public void enterLinea(LineaContext ctx) {
		_tablasimbolos.newRow();
	}
	
	@Override
	public void exitRutaFicheroJson(RutaFicheroJsonContext ctx) {
		_tablasimbolos.addValue("rutafichero", ctx.rutafichero().getText());
	}
	
	@Override
	public void exitRutaFicheroDot(RutaFicheroDotContext ctx) {
		_tablasimbolos.addValue("rutaficherosalida", ctx.rutaficherosalida().getText());
	}
	
	@Override
	public void exitRutaFicheroSvg(RutaFicheroSvgContext ctx) {
		_tablasimbolos.addValue("rutaficherografico", ctx.rutaficherografico().getText());
	}
	
	@Override
	public void exitTextoNombre(TextoNombreContext ctx) {
		_tablasimbolos.addValue("nombre", ctx.nombre().getText());
	}
	
	@Override
	public void exitCampoVacio(CampoVacioContext ctx) {
		_tablasimbolos.addValue(CSVListener_TipoAvanzadoTS.CAMPO_VACIO);
	}	
	
}

